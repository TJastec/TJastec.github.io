﻿namespace softwareSales
{
    partial class salesForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(salesForm1));
            this.packagesSoldGroupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxC = new System.Windows.Forms.TextBox();
            this.textBoxB = new System.Windows.Forms.TextBox();
            this.textBoxA = new System.Windows.Forms.TextBox();
            this.cPackageLabel4 = new System.Windows.Forms.Label();
            this.bPackageLabel3 = new System.Windows.Forms.Label();
            this.aPackageALabel = new System.Windows.Forms.Label();
            this.entertheNumberLabel = new System.Windows.Forms.Label();
            this.revenueGroupBox2 = new System.Windows.Forms.GroupBox();
            this.totalRevenueTextBox = new System.Windows.Forms.TextBox();
            this.cRevenueTextBox = new System.Windows.Forms.TextBox();
            this.bRevenueTextBox = new System.Windows.Forms.TextBox();
            this.aRevenueTextBox = new System.Windows.Forms.TextBox();
            this.totalLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bREVENUElabel = new System.Windows.Forms.Label();
            this.aREVENUElabel = new System.Windows.Forms.Label();
            this.calculateButton1 = new System.Windows.Forms.Button();
            this.clearButton2 = new System.Windows.Forms.Button();
            this.exitButton3 = new System.Windows.Forms.Button();
            this.packagesSoldGroupBox1.SuspendLayout();
            this.revenueGroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // packagesSoldGroupBox1
            // 
            this.packagesSoldGroupBox1.Controls.Add(this.textBoxC);
            this.packagesSoldGroupBox1.Controls.Add(this.textBoxB);
            this.packagesSoldGroupBox1.Controls.Add(this.textBoxA);
            this.packagesSoldGroupBox1.Controls.Add(this.cPackageLabel4);
            this.packagesSoldGroupBox1.Controls.Add(this.bPackageLabel3);
            this.packagesSoldGroupBox1.Controls.Add(this.aPackageALabel);
            this.packagesSoldGroupBox1.Controls.Add(this.entertheNumberLabel);
            this.packagesSoldGroupBox1.Location = new System.Drawing.Point(72, 51);
            this.packagesSoldGroupBox1.Name = "packagesSoldGroupBox1";
            this.packagesSoldGroupBox1.Size = new System.Drawing.Size(318, 371);
            this.packagesSoldGroupBox1.TabIndex = 0;
            this.packagesSoldGroupBox1.TabStop = false;
            this.packagesSoldGroupBox1.Text = "Packages Sold";
            // 
            // textBoxC
            // 
            this.textBoxC.Location = new System.Drawing.Point(112, 297);
            this.textBoxC.Name = "textBoxC";
            this.textBoxC.Size = new System.Drawing.Size(147, 20);
            this.textBoxC.TabIndex = 6;
            // 
            // textBoxB
            // 
            this.textBoxB.Location = new System.Drawing.Point(112, 202);
            this.textBoxB.Name = "textBoxB";
            this.textBoxB.Size = new System.Drawing.Size(147, 20);
            this.textBoxB.TabIndex = 5;
            // 
            // textBoxA
            // 
            this.textBoxA.Location = new System.Drawing.Point(112, 101);
            this.textBoxA.Name = "textBoxA";
            this.textBoxA.Size = new System.Drawing.Size(147, 20);
            this.textBoxA.TabIndex = 4;
            // 
            // cPackageLabel4
            // 
            this.cPackageLabel4.AutoSize = true;
            this.cPackageLabel4.Location = new System.Drawing.Point(33, 300);
            this.cPackageLabel4.Name = "cPackageLabel4";
            this.cPackageLabel4.Size = new System.Drawing.Size(70, 13);
            this.cPackageLabel4.TabIndex = 3;
            this.cPackageLabel4.Text = "PACKAGE C:";
            // 
            // bPackageLabel3
            // 
            this.bPackageLabel3.AutoSize = true;
            this.bPackageLabel3.Location = new System.Drawing.Point(33, 205);
            this.bPackageLabel3.Name = "bPackageLabel3";
            this.bPackageLabel3.Size = new System.Drawing.Size(70, 13);
            this.bPackageLabel3.TabIndex = 2;
            this.bPackageLabel3.Text = "PACKAGE B:";
            // 
            // aPackageALabel
            // 
            this.aPackageALabel.AutoSize = true;
            this.aPackageALabel.Location = new System.Drawing.Point(33, 104);
            this.aPackageALabel.Name = "aPackageALabel";
            this.aPackageALabel.Size = new System.Drawing.Size(73, 13);
            this.aPackageALabel.TabIndex = 1;
            this.aPackageALabel.Text = "PACKAGE A: ";
            // 
            // entertheNumberLabel
            // 
            this.entertheNumberLabel.AutoSize = true;
            this.entertheNumberLabel.Location = new System.Drawing.Point(33, 34);
            this.entertheNumberLabel.Name = "entertheNumberLabel";
            this.entertheNumberLabel.Size = new System.Drawing.Size(265, 13);
            this.entertheNumberLabel.TabIndex = 0;
            this.entertheNumberLabel.Text = "Enter the number of packages sold for each packeage";
            // 
            // revenueGroupBox2
            // 
            this.revenueGroupBox2.Controls.Add(this.totalRevenueTextBox);
            this.revenueGroupBox2.Controls.Add(this.cRevenueTextBox);
            this.revenueGroupBox2.Controls.Add(this.bRevenueTextBox);
            this.revenueGroupBox2.Controls.Add(this.aRevenueTextBox);
            this.revenueGroupBox2.Controls.Add(this.totalLabel);
            this.revenueGroupBox2.Controls.Add(this.label1);
            this.revenueGroupBox2.Controls.Add(this.bREVENUElabel);
            this.revenueGroupBox2.Controls.Add(this.aREVENUElabel);
            this.revenueGroupBox2.Location = new System.Drawing.Point(510, 51);
            this.revenueGroupBox2.Name = "revenueGroupBox2";
            this.revenueGroupBox2.Size = new System.Drawing.Size(318, 371);
            this.revenueGroupBox2.TabIndex = 1;
            this.revenueGroupBox2.TabStop = false;
            this.revenueGroupBox2.Text = "Revenue Gener8ed";
            // 
            // totalRevenueTextBox
            // 
            this.totalRevenueTextBox.Location = new System.Drawing.Point(116, 294);
            this.totalRevenueTextBox.Name = "totalRevenueTextBox";
            this.totalRevenueTextBox.ReadOnly = true;
            this.totalRevenueTextBox.Size = new System.Drawing.Size(147, 20);
            this.totalRevenueTextBox.TabIndex = 10;
            // 
            // cRevenueTextBox
            // 
            this.cRevenueTextBox.Location = new System.Drawing.Point(116, 215);
            this.cRevenueTextBox.Name = "cRevenueTextBox";
            this.cRevenueTextBox.ReadOnly = true;
            this.cRevenueTextBox.Size = new System.Drawing.Size(147, 20);
            this.cRevenueTextBox.TabIndex = 9;
            // 
            // bRevenueTextBox
            // 
            this.bRevenueTextBox.Location = new System.Drawing.Point(116, 134);
            this.bRevenueTextBox.Name = "bRevenueTextBox";
            this.bRevenueTextBox.ReadOnly = true;
            this.bRevenueTextBox.Size = new System.Drawing.Size(147, 20);
            this.bRevenueTextBox.TabIndex = 8;
            // 
            // aRevenueTextBox
            // 
            this.aRevenueTextBox.Location = new System.Drawing.Point(116, 50);
            this.aRevenueTextBox.Name = "aRevenueTextBox";
            this.aRevenueTextBox.ReadOnly = true;
            this.aRevenueTextBox.Size = new System.Drawing.Size(147, 20);
            this.aRevenueTextBox.TabIndex = 7;
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(73, 297);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(34, 13);
            this.totalLabel.TabIndex = 5;
            this.totalLabel.Text = "Total:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 218);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "PACKAGE C:";
            // 
            // bREVENUElabel
            // 
            this.bREVENUElabel.AutoSize = true;
            this.bREVENUElabel.Location = new System.Drawing.Point(37, 137);
            this.bREVENUElabel.Name = "bREVENUElabel";
            this.bREVENUElabel.Size = new System.Drawing.Size(70, 13);
            this.bREVENUElabel.TabIndex = 1;
            this.bREVENUElabel.Text = "PACKAGE B:";
            // 
            // aREVENUElabel
            // 
            this.aREVENUElabel.AutoSize = true;
            this.aREVENUElabel.Location = new System.Drawing.Point(37, 53);
            this.aREVENUElabel.Name = "aREVENUElabel";
            this.aREVENUElabel.Size = new System.Drawing.Size(70, 13);
            this.aREVENUElabel.TabIndex = 0;
            this.aREVENUElabel.Text = "PACKAGE A:";
            // 
            // calculateButton1
            // 
            this.calculateButton1.Location = new System.Drawing.Point(126, 529);
            this.calculateButton1.Name = "calculateButton1";
            this.calculateButton1.Size = new System.Drawing.Size(206, 49);
            this.calculateButton1.TabIndex = 2;
            this.calculateButton1.Text = "&Calculate Revenue";
            this.calculateButton1.UseVisualStyleBackColor = true;
            this.calculateButton1.Click += new System.EventHandler(this.calculateButton1_Click);
            // 
            // clearButton2
            // 
            this.clearButton2.Location = new System.Drawing.Point(338, 529);
            this.clearButton2.Name = "clearButton2";
            this.clearButton2.Size = new System.Drawing.Size(206, 49);
            this.clearButton2.TabIndex = 3;
            this.clearButton2.Text = "CLEAR";
            this.clearButton2.UseVisualStyleBackColor = true;
            this.clearButton2.Click += new System.EventHandler(this.clearButton2_Click);
            // 
            // exitButton3
            // 
            this.exitButton3.Location = new System.Drawing.Point(550, 529);
            this.exitButton3.Name = "exitButton3";
            this.exitButton3.Size = new System.Drawing.Size(206, 49);
            this.exitButton3.TabIndex = 4;
            this.exitButton3.Text = "E&XIT";
            this.exitButton3.UseVisualStyleBackColor = true;
            this.exitButton3.Click += new System.EventHandler(this.exitButton3_Click);
            // 
            // salesForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(897, 613);
            this.Controls.Add(this.exitButton3);
            this.Controls.Add(this.clearButton2);
            this.Controls.Add(this.calculateButton1);
            this.Controls.Add(this.revenueGroupBox2);
            this.Controls.Add(this.packagesSoldGroupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "salesForm1";
            this.Text = "Software Sales";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.packagesSoldGroupBox1.ResumeLayout(false);
            this.packagesSoldGroupBox1.PerformLayout();
            this.revenueGroupBox2.ResumeLayout(false);
            this.revenueGroupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox packagesSoldGroupBox1;
        private System.Windows.Forms.Label cPackageLabel4;
        private System.Windows.Forms.Label bPackageLabel3;
        private System.Windows.Forms.Label aPackageALabel;
        private System.Windows.Forms.Label entertheNumberLabel;
        private System.Windows.Forms.GroupBox revenueGroupBox2;
        private System.Windows.Forms.TextBox textBoxC;
        private System.Windows.Forms.TextBox textBoxB;
        private System.Windows.Forms.TextBox textBoxA;
        private System.Windows.Forms.Button calculateButton1;
        private System.Windows.Forms.Button clearButton2;
        private System.Windows.Forms.Button exitButton3;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label bREVENUElabel;
        private System.Windows.Forms.Label aREVENUElabel;
        private System.Windows.Forms.TextBox totalRevenueTextBox;
        private System.Windows.Forms.TextBox cRevenueTextBox;
        private System.Windows.Forms.TextBox bRevenueTextBox;
        private System.Windows.Forms.TextBox aRevenueTextBox;
    }
}

